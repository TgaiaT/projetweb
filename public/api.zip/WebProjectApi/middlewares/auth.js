var data = require('../controlers/dataManipulator.js');
/*
*	Set the permissions for the tables
*/
var routes = [
	//Ressource tables
	{
		"path": "users",
		"method": "ALL",
		"levelRequired": 5
	},
	{
		"path": "commands",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "comments",
		"method": "ALL",
		"levelRequired": 5
	},
	{
		"path": "pictures",
		"method": "ALL",
		"levelRequired": 5
	},
	{
		"path": "ranks",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "states",
		"method": "ALL",
		"levelRequired": 5
	},
	{
	//Categories
		"path": "categories",
		"method": "POST",
		"levelRequired": 5
	},
	{
		"path": "categories",
		"method": "PUT",
		"levelRequired": 5
	},
	{
		"path": "categories",
		"method": "DELETE",
		"levelRequired": 5
	},
	{
	//Activities
		"path": "activities",
		"method": "POST",
		"levelRequired": 1
	},
	{
		"path": "activities",
		"method": "PUT",
		"levelRequired": 4
	},
	{
		"path": "activities",
		"method": "DELETE",
		"levelRequired": 5
	},
	{
	//Manifestations
		"path": "manifestations",
		"method": "POST",
		"levelRequired": 5
	},
	{
		"path": "manifestations",
		"method": "PUT",
		"levelRequired": 5
	},
	{
		"path": "manifestations",
		"method": "DELETE",
		"levelRequired": 5
	},
	//Associative tables
	{
		"path": "based",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "contain",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "fit",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "liked",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "located",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "signin",
		"method": "ALL",
		"levelRequired": 10
	},
	{
		"path": "vote",
		"method": "ALL",
		"levelRequired": 10
	},
];

/*
*	Authentication function. It is called before send the response to the client.
*/
var auth = async function (req, res, next) {
	// Get the token
	var token = req.headers.authorization;
	
	var result;
	/*
	*	Get the rank level of the player by comparing the user's token.
	*/
	try {
		result = await (async function() {
			return new Promise(async function (resolve,reject) {
				await data.connection.query("select * from users inner join ranks where (token = ?) AND (users.id_rank = ranks.id_rank)", token, async function(qerr,qres,qfields){
					if (qerr == null && qres != "")
					{
						if (qres.length > 1)
						{
							reject({
								"isValid": false,
								"rankLevel": 0,
								"error" : "No token found"
							});
						}
						else
						{
							resolve({
								"isValid": true,
								"rankLevel": qres[0].level
							});
						}
					}
					else
					{
						reject({
							"isValid": false,
							"rankLevel": 0,
							"error" : "No token found"
						});
					}
				});
			});
		})()
	}catch(error)
	{
		result = error;
	}
	
	/*
	*	Check if the user have the required permissions
	*/
	req.rankLevel = result.rankLevel;
	var path = req.path.split('/');
	var isPermit = true;

	for (i=0; i < routes.length; i++)
	{
		if (path[1] == routes[i].path && (req.method == routes[i].method || routes[i].method == "ALL"))
		{
			if (result.rankLevel < routes[i].levelRequired)
			{
				// If the user doesn't have required permissions
				isPermit = false;
				res.status(400).json({
					"error": "You don't have the permission to do that"
				});
			}
		}
	}
	if (isPermit)
	{
		// If auth function allows the user
		next();
	}

}

module.exports = auth;