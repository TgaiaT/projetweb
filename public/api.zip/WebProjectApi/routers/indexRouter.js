var express = require('express');
var router = express.Router();
var data = require('../controlers/dataManipulator.js');
var sha256 = require('js-sha256');

/*
*	Manage the specified route. Select all elements.
*/
router.route('/')
.all(function(req,res){
	res.status(200).json({
	message: "Welcome to the BDE API of the Cesi Nancy Campus. Documentation of the API : vandeiheim.ovh/contact"
	});
});

/*
*	Manage the specified route. Get the token.
*/
router.route('/token')
.post(async function(req,res){
	if (req.body.login != null && req.body.password != null)
	{
		var result = await data.read({
			"from": "users",
			"select": "token",
			"where": "users.email = " + data.connection.escape(req.body.login) + " AND users.password = '" + sha256(req.body.password) + "'"
		});
		res.json(result);
	}
	else
	{
		res.status(400).json({
			"error": "Login and password are required !"
		});
	}
});

module.exports = router;