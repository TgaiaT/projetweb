var express = require('express');
var router = express.Router();
var data = require('../controlers/dataManipulator.js');

/*
*	Information about the ressource
*/
var ressourceName = "activity";

/*
*	Manage the specified route. Select all elements.
*/
router.route('/' + ressourceName.plural())
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = "";
	
	if (req.query.precision == "max" && req.rankLevel >= 5)
	{
		_from.push("states");
		_from.push("users");
		var condition = " (activities.id_user = users.id_user) AND (activities.id_state = states.id_state) ";
		_where += (_where == "") ? condition : " AND " + condition;
	}
	
	if (req.query.getRegistered == "true" && req.rankLevel >= 5)
	{
		_from.push("signin");
		if (! _from.includes("users")) _from.push("users");
		var condition = " users.id_user = signin.id_user AND activities.id_activity = signin.id_activity ";
		_where += (_where == "") ? condition : " AND " + condition;
	}
	
	if (req.query.getVoters == "true" && req.rankLevel >= 5)
	{
		_from.push("vote");
		if (! _from.includes("users")) _from.push("users");
		var condition = " users.id_user = vote.id_user AND activities.id_activity = vote.id_activity ";
		_where += (_where == "") ? condition : " AND " + condition;
	}
	
	if (_where == "")
	{
		var result = await data.read({"from": _from, "select": "*"});
	}
	else
	{
		var result = await data.read({"from": _from, "select": "*", "where": _where});
	}
	res.json(result);
})
.post(async function(req,res) {
	var result = await data.create({"from": ressourceName.plural(), "values": req.body.values});
	res.json(result);
});

/*
*	Manage the specified route. Select a specific element.
*/
router.route("/"+ ressourceName.plural() +"/:"+ ressourceName +"_id")
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = ressourceName.plural() + ".id_"+ ressourceName +" = " + req.params[ressourceName + "_id"];
	
	if (req.query.precision == "max" && req.rankLevel >= 5)
	{
		_from.push("states");
		_from.push("users");
		var condition = " (activities.id_user = users.id_user) AND (activities.id_state = states.id_state) ";
		_where += " AND " + condition;
	}
	
	if (req.query.getRegistered == "true" && req.rankLevel >= 5)
	{
		_from.push("signin");
		if (! _from.includes("users")) _from.push("users");
		var condition = " users.id_user = signin.id_user AND activities.id_activity = signin.id_activity ";
		_where += " AND " + condition;
	}
	
	if (req.query.getVoters == "true" && req.rankLevel >= 5)
	{
		_from.push("vote");
		if (! _from.includes("users")) _from.push("users");
		var condition = " users.id_user = vote.id_user AND activities.id_activity = vote.id_activity ";
		_where += " AND " + condition;
	}
	
	var result = await data.read({"from": _from, "select": "*", "where": _where});
	res.json(result);
})
.delete(async function(req,res) {
	var result = await data.delete({"from": ressourceName.plural(), "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
})
.put(async function(req,res) {
	var result = await data.update({"from": ressourceName.plural(), "values": req.body.values, "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
});

module.exports = router;