var express = require('express');
var router = express.Router();
var data = require('../../controlers/dataManipulator.js');

/*
*	Information about the ressource
*/
var ressourceName = "located";
var firstId = "event";
var secondId = "campus";

/*
*	Manage the specified route. Select all elements.
*/
router.route('/' + ressourceName)
.get(async function(req,res) {
	var result = await data.read({"from": ressourceName, "select": "*"});
	res.json(result);
})
.post(async function(req,res) {
	var result = await data.create({"from": ressourceName, "values": req.body.values});
	res.json(result);
});

/*
*	Manage the specified route. Select a specific element.
*/
router.route("/"+ ressourceName +"/:"+ firstId +"_id/:" + secondId + "_id")
.get(async function(req,res) {
	var result = await data.read({
		"from": ressourceName, 
		"select": "*", 
		"where": "id_"+ firstId +" = " + req.params[firstId + "_id"] + " AND id_" + secondId +" = " + req.params[secondId + "_id"]
		});
	res.json(result);
})
.delete(async function(req,res) {
	var result = await data.delete({
		"from": ressourceName, 
		"where": "id_"+ firstId +" = " + req.params[firstId + "_id"] + " AND id_" + secondId +" = " + req.params[secondId + "_id"]
		});
	res.json(result);
})
.put(async function(req,res) {
	var result = await data.update({
		"from": ressourceName, 
		"values": req.body.values, 
		"where": "id_"+ firstId +" = " + req.params[firstId + "_id"] + " AND id_" + secondId +" = " + req.params[secondId + "_id"]
		});
	res.json(result);
});

module.exports = router;