var express = require('express');
var router = express.Router();
var data = require('../controlers/dataManipulator.js');

/*
*	Information about the ressource
*/
var ressourceName = "comment";

/*
*	Manage the specified route. Select all elements.
*/
router.route('/' + ressourceName.plural())
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = "";
	
	if (req.query.precision == "max")
	{
		_from.push("users");
		_from.push("pictures");
		_from.push("states");
		var condition = " users.id_user = comments.id_user AND states.id_state = comments.id_state AND pictures.id_picture = comments.id_picture ";
		_where += (_where == "") ? condition : " AND " + condition;
	}
	
	if (_where == "")
	{
		var result = await data.read({"from": _from, "select": "*"});
	}
	else
	{
		var result = await data.read({"from": _from, "select": "*", "where": _where});
	}
	res.json(result);
})
.post(async function(req,res) {
	var result = await data.create({"from": ressourceName.plural(), "values": req.body.values});
	res.json(result);
});

/*
*	Manage the specified route. Select a specific element.
*/
router.route("/"+ ressourceName.plural() +"/:"+ ressourceName +"_id")
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = ressourceName.plural() + ".id_"+ ressourceName +" = " + req.params[ressourceName + "_id"];
	
	if (req.query.precision == "max")
	{
		_from.push("users");
		_from.push("pictures");
		_from.push("states");
		var condition = " users.id_user = comments.id_user AND states.id_state = comments.id_state AND pictures.id_picture = comments.id_picture ";
		_where += " AND " + condition;
	}
	
	var result = await data.read({"from": _from, "select": "*", "where": _where});
	res.json(result);
})
.delete(async function(req,res) {
	var result = await data.delete({"from": ressourceName.plural(), "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
})
.put(async function(req,res) {
	var result = await data.update({"from": ressourceName.plural(), "values": req.body.values, "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
});

module.exports = router;