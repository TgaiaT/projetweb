var express = require('express');
var router = express.Router();
var data = require('../controlers/dataManipulator.js');

/*
*	Information about the ressource
*/
var ressourceName = "campus";

/*
*	Manage the specified route. Select all elements.
*/
router.route('/' + ressourceName.plural())
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = "";
	
	if (req.query.getProducts == "true")
	{
		_from.push("based");
		_from.push("products");
		_from.push("states");
		var condition = " campus.id_campus = based.id_campus AND based.id_product = products.id_product AND states.id_state = products.id_state ";
		_where += (_where == "") ? condition : " AND " + condition;
	}
	
	if (_where == "")
	{
		var result = await data.read({"from": _from, "select": "*"});
	}
	else
	{
		var result = await data.read({"from": _from, "select": "*", "where": _where});
	}
	res.json(result);
})
.post(async function(req,res) {
	var result = await data.create({"from": ressourceName.plural(), "values": req.body.values});
	res.json(result);
});

/*
*	Manage the specified route. Select a specific element.
*/
router.route("/"+ ressourceName.plural() +"/:"+ ressourceName +"_id")
.get(async function(req,res) {
	var _from = [ressourceName.plural()];
	var _where = ressourceName.plural() + ".id_"+ ressourceName +" = " + req.params[ressourceName + "_id"];
	
	if (req.query.getProducts == "true")
	{
		_from.push("based");
		_from.push("products");
		_from.push("states");
		var condition = " campus.id_campus = based.id_campus AND based.id_product = products.id_product AND states.id_state = products.id_state ";
		_where += " AND " + condition;
	}
	
	var result = await data.read({"from": _from, "select": "*", "where": _where});
	res.json(result);
})
.delete(async function(req,res) {
	var result = await data.delete({"from": ressourceName.plural(), "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
})
.put(async function(req,res) {
	var result = await data.update({"from": ressourceName.plural(), "values": req.body.values, "where": "id_"+ ressourceName +" = " + req.params[ressourceName + "_id"]});
	res.json(result);
});

module.exports = router;