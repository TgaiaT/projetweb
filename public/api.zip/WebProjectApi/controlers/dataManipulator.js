/*
*	Object that can execute quesry the database.
*/
var data = {
	// The connection to the BDD
	connection: null,
	// Id of the connection
	getId: function() {
		console.log(data.connection.threadId);
	},
	// Read operation (i.e. CRUD)
	read: function(options, callback)
	{
		/*
		* Return a promise to wait the end of the SQL query.
		*/ 
		return new Promise(function (resolve, reject){
			var sql = "select ?? from ?? ";
			if (options.select != null && options.from != null)
			{
				if (options.where != null)
				{
					sql += " where " + options.where;
				}
				if (options.order != null)
				{
					sql += " order by " + options.order;
				}
				if (options.limit != null)
				{
					sql += " limit " + options.limit;
				}
				// Execute the query
				data.connection.query({"sql": sql, nestTables: ':'}, [options.select, options.from], function(err,res,fields){
					resolve({
						"error": err,
						"result": res,
						"fields": fields,
					});
				});
			}
			else
			{
				reject({
					"error": "true"
				});
			}
		});
	},
	// Create operation (i.e CRUD)
	create: function(options, callback)
	{
		/*
		* Return a promise to wait the end of the SQL query.
		*/ 
		return new Promise(function (resolve, reject){
			var sql = "insert into ?? set ?";
			if (options.from != null && options.values != null)
			{
				// Execute the query
				data.connection.query(sql, [options.from, options.values], function(error,result,fields){
					resolve({
						"error": error,
						"result": result,
						"fields": fields,
					});
				});
			}
			else
			{
				reject({
					"error": "true"
				});
			}
		});
	},
	// Delete operation (i.e CRUD)
	delete: function(options, callback) {
		/*
		* Return a promise to wait the end of the SQL query.
		*/ 
		return new Promise(function (resolve, reject){
			var sql = "delete from ?? where ";
			if (options.from != null && options.where != null)
			{
				sql += options.where;
				// Execute the query
				data.connection.query(sql, options.from, function (error, result, fields){
					resolve({
						"error": error,
						"result": result,
						"fields": fields,
					});
				});
			}
			else
			{
				reject({
					"error": "true"
				});
			}
		});
	},
	// Update operation (i.e CRUD)
	update: function(options, callback) {
		/*
		* Return a promise to wait the end of the SQL query.
		*/ 
		return new Promise(function (resolve, reject){
			var sql = "update ?? set ? ";
			if (options.from != null && options.values != null)
			{
				if (options.where != null)
				{
					sql += "where " + options.where;
				}
				// Execute the query
				data.connection.query(sql, [options.from, options.values], function (error, result, fields){
					resolve({
						"error": error,
						"result": result,
						"fields": fields,
					});
				});
			}
			else
			{
				reject({
					"error": "true"
				});
			}
		});
	},
	
}

// Export the object
module.exports = data;