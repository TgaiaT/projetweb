var express = require('express');
var mysql = require('mysql');
var app = express();
require('./controlers/wordManipulator.js');

/*
*	Informations about node server
*/
var hostname = '192.168.0.100'; 
var port = 3000;

/*
*	Informations about Mysql
*/
var connection = mysql.createConnection({
	host: 'localhost',
	user: 'wananas',
	password: 'Jaimelananas041199@',
	database: 'web_project'
});
connection.connect(function(err){
	if (err){
		console.log(err);
		return;
	}
	
	console.log('Connection successful');
	
	/*
	*	Middlewares
	*/
	var data = require('./controlers/dataManipulator.js');
	data.connection = connection;
	var bodyParser = require("body-parser")
	app.use(bodyParser.urlencoded({ extended: true }));
	app.use(bodyParser.json());
	var auth = require('./middlewares/auth.js');

	/*
	*	The routers for the main ressources
	*/
	var index = require('./routers/indexRouter.js');
	var activities = require('./routers/activitiesRouter.js');
	var campus = require('./routers/campusRouter.js');
	var categories = require('./routers/categoriesRouter.js');
	var commands = require('./routers/commandsRouter.js');
	var comments = require('./routers/commentsRouter.js');
	var events = require('./routers/eventsRouter.js');
	var pictures = require('./routers/picturesRouter.js');
	var products = require('./routers/productsRouter.js');
	var ranks = require('./routers/ranksRouter.js');
	var states = require('./routers/statesRouter.js');
	var users = require('./routers/usersRouter.js');

	/*
	*	The routers for the associatives table
	*/
	var based = require('./routers/Associative_tables/basedRouter.js');
	var contain = require('./routers/Associative_tables/containRouter.js');
	var fit = require('./routers/Associative_tables/fitRouter.js');
	var liked = require('./routers/Associative_tables/likedRouter.js');
	var located = require('./routers/Associative_tables/locatedRouter.js');
	var signin = require('./routers/Associative_tables/signinRouter.js');
	var vote = require('./routers/Associative_tables/voteRouter.js');
	
	
	//Start Middlewares
	app.use(auth);

	//Main ressources
	app.use(index);
	app.use(activities);
	app.use(campus);
	app.use(categories);
	app.use(commands);
	app.use(comments);
	app.use(events);
	app.use(pictures);
	app.use(products);
	app.use(ranks);
	app.use(states);
	app.use(users);
	
	//Associatives table
	app.use(based);
	app.use(contain);
	app.use(fit);
	app.use(liked);
	app.use(located);
	app.use(signin);
	app.use(vote);
	
	//Start the server
	app.listen(port, hostname, function(){
		console.log("Mon serveur fonctionne sur http://"+ hostname +":"+port); 
	});
});